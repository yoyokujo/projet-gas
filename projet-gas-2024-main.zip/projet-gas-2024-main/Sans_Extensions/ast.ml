type programme = ligne list

and ligne = int * instr

and instr =
  | Imprime of expr_list list
  | Si of expr * relop * expr * instr
  | Vavers of expr
  | Entree of char list
  | Assign of char * expr
  | Fin
  | Rem of string
  | Nl

and expr_list = 
  | String of string
  | Expr of expr

and expr =
  | Nombre of int
  | Var of char
  | Op of expr * op * expr
  | Neg of expr

and op = Plus | Minus | Times | Divide

and relop = Equal | Lessthan | Greaterthan | Lessthanequal | Greaterthanequal | Notequal







