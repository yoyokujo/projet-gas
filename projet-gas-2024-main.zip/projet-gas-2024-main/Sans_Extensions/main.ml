open Ast

(* Tableau contenant les 26 variables toutes initialisées
   à 0 *)
let variable = Array.make 26 0

(* Renvoie l'index d'une lettre dans le tableau *)
let index_of_letter letter = 
    Char.code (Char.uppercase_ascii letter) - Char.code 'A'

(* Modifie les variables *)
let set_variable letter value =
    let index = index_of_letter letter in
    variable.(index) <- value

(* Récupère la valeur d'une variable *)
let get_variable letter =
    let index = index_of_letter letter in
    variable.(index)

(* Lis un entier dans le terminal et modifie la variable
   correspondante *)
let rec read_value letter =
    Printf.printf "Entrez la valeur pour %c : " letter;
    let tmp = read_int_opt () in
    match tmp with
    | None -> read_value letter
    | Some value -> set_variable letter value

(* Lis une liste de variables et rappelle la fonction
   read_value pour chaque variable *)
let rec set_variable_list (value_list : char list) = 
    match value_list with
    | h :: t -> read_value h ; set_variable_list t
    | _ -> ()

(* Évalue une expression, renvoie:
   - un nombre
   - une variable
   - le résultat d'une opération arithmétique *)
let rec eval_expr expr =  
    match expr with
    | Nombre n -> n
    | Var v -> get_variable v
    | Op (e1, op, e2) -> 
        let v1 = eval_expr e1 in
        let v2 = eval_expr e2 in
        begin match op with
        | Plus -> v1 + v2
        | Minus -> v1 - v2
        | Times -> v1 * v2
        | Divide -> v1 / v2
        end
    | Neg v -> - (eval_expr v)

(* Fonction en charge de VAVER, renvoie la dernière
   instruction avec le numéro de ligne recherché
   et dans le cas où il n'existe pas, renvoie une erreur *)
let rec vavers_instr (line : int) (prev_data : ligne list) (data : ligne list) (is_last : bool) = 
    match data with
    | [] -> if is_last then prev_data else failwith "Pas de ligne avec cette valeur."
    | (l, _) :: t -> if is_last then (if l = line then (vavers_instr line data t true) else prev_data) else (if l = line then (vavers_instr line data t true) else (vavers_instr line data t false))

(* Fonction principale en charge de la lecture des lignes
   du programme et exécute le nécessaire pour chaque
   instruction *)
let rec lecture_line (data : ligne list) (save : ligne list) = 
    match data with
    | [] -> ()
    | (_, instru) :: t -> let rec instruction data = 
    begin match data with
        | Imprime expr -> List.iter (fun expr -> match expr with
            | String s -> print_string (String.sub s 1 (String.length s - 2));
            | Expr e -> print_int (eval_expr e) ) expr; 
            print_newline (); lecture_line t save
        | Si (e1, op, e2, instr) ->
            let v1 = eval_expr e1 in
            let v2 = eval_expr e2 in
            let result = begin match op with
                | Equal -> v1 = v2
                | Notequal -> v1 <> v2
                | Lessthan -> v1 < v2
                | Lessthanequal -> v1 <= v2
                | Greaterthan -> v1 > v2
                | Greaterthanequal -> v1 >= v2
                end
            in
            if result then instruction instr
            else lecture_line t save
        | Vavers expr -> 
            begin match expr with
                | Nombre nb -> lecture_line (vavers_instr nb save save false) save
                | _ -> failwith "Expression invalide"
            end
        | Entree expr -> set_variable_list expr; lecture_line t save
        | Assign (var, expr) ->
            let value = eval_expr expr in
            set_variable var value; lecture_line t save
        | Fin -> (exit 0)
        | Rem _ -> (); lecture_line t save
        | Nl -> print_newline (); lecture_line t save
        end in
        instruction instru

(* Fonction qui vérifie si le programme est vide ou 
   contient uniquement des commentaires *)
let rec vide_or_rem prog = 
    match prog with
    | [] -> true
    | (_, Rem _) :: t -> vide_or_rem t
    | _ -> false

(* Lancement du programme qui lit un fichier en entré,
   exécute le parsing *)
let () =
    if Array.length Sys.argv < 2 then
    failwith "Veuillez fournir le nom du fichier en argument uniquement.";
    let filename = Sys.argv.(1) in
    let ic = open_in filename in
    let lexbuf = Lexing.from_channel ic in
    let result = Parser.programme Lexer.main lexbuf in
    let result_sorted = List.sort (fun (a, _) (b, _) -> compare a b) result in
    if vide_or_rem result_sorted then
        failwith "Le programme est vide."
    else
    lecture_line result_sorted result_sorted;
    close_in ic 